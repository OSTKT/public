% Store simulation scope data
ScopeDataGS = simOut_GS.ScopeDataGS;
ScopeDataSingle = simOut_single.ScopeDataGS;

% Obtain detailed step-response characteristics
% from 1 to 5
S1 = stepinfo(ScopeDataGS.signals.values(1:10000),...
    ScopeDataGS.time(1:10000),5,1);
S1s = stepinfo(ScopeDataSingle.signals.values(1:10000),...
    ScopeDataSingle.time(1:10000),5,1);

% from 5 to 10
S2 = stepinfo(ScopeDataGS.signals.values(60002:70001),...
    ScopeDataGS.time(60002:70001),10,5);
S2s = stepinfo(ScopeDataSingle.signals.values(60002:70001),...
    ScopeDataSingle.time(60002:70001),10,5);

% from 10 to 15
S3 = stepinfo(ScopeDataGS.signals.values(120002:130001),...
    ScopeDataGS.time(120002:130001),15,10);
S3s = stepinfo(ScopeDataSingle.signals.values(120002:130001),...
    ScopeDataSingle.time(120002:130001),15,10);

% from 15 to 20
S4 = stepinfo(ScopeDataGS.signals.values(180002:190001),...
    ScopeDataGS.time(180002:190001),20,15);
S4s = stepinfo(ScopeDataSingle.signals.values(180002:190001),...
    ScopeDataSingle.time(180002:190001),20,15);

% Store rise time and overshoot for both controllers 
h1 = [S1s.RiseTime S1s.Overshoot; S1.RiseTime S1.Overshoot];
h2 = [S2s.RiseTime S2s.Overshoot; S2.RiseTime S2.Overshoot];
h3 = [S3s.RiseTime S3s.Overshoot; S3.RiseTime S3.Overshoot];
h4 = [S4s.RiseTime S4s.Overshoot; S4.RiseTime S4.Overshoot];

ControllerType = {'Single PID';'Gain-Scheduled'};
OperatingPoints = {'H = 1 to 5','H = 5 to 10',...
                   'H = 10 to 15','H = 15 to 20'};

% Create Tables
RiseTime = table(h1(:,1),h2(:,1),h3(:,1),h4(:,1),...
    'RowNames',ControllerType,'VariableNames', OperatingPoints)

Overshoot = table(h1(:,2),h2(:,2),h3(:,2),h4(:,2),...
    'RowNames',ControllerType,'VariableNames', OperatingPoints)
