%% Tune PID Controller in Real Time Using Closed-Loop PID Autotuner Block
% This example shows how to use the Closed-Loop PID Autotuner block to tune
% a PID controller for a boost converter plant in both simulation and real
% time.

% Copyright 2020 The MathWorks, Inc.

%% Closed-Loop PID Autotuner Block
% The Closed-Loop PID Autotuner block allows you to tune a single-loop PID
% controller in both simulation and real time. The block injects sinusoidal
% perturbation signals at the plant input and measures the plant output
% during a closed-loop experiment. When the experiment stops, the block
% computes PID gains based on the plant frequency responses estimated near
% the desired bandwidth.
% 
% The Closed-Loop PID Autotuner block supports two typical PID tuning
% scenarios in real-time applications. 
% 
% # Deploy the block on hardware and use it in a standalone real-time
% application, without the presence of Simulink(R). 
% # Deploy the block on hardware but monitor and manage the real-time
% tuning process in Simulink, using external simulation mode. External
% mode allows communication between the Simulink block diagram running on
% the host computer and the generated code running on the hardware.
%
% This example focuses on the first scenario, deploying the block to
% perform the real-time tuning.
%
% Simulink Control Design(TM) software also provides an Open-Loop PID
% Autotuner block for real-time PID tuning. The main difference between the
% two autotuner blocks is that the Open-Loop PID Autotuner block carries
% out the experiment with the feedback loop open (that is, the existing
% controller is not in action). To decide which autotuner block is best for
% your application, consider the following points:
%
% * If you do not have an initial controller, use the Open-Loop PID
% Autotuner block to obtain one. You can continue using it to retune the
% controller or replace it with the Closed-Loop PID Autotuner block.
% * If you have an initial controller, use the Closed-Loop PID Autotuner
% block for retuning. The major benefits are: (1) if there is an
% unexpected disturbance during the experiment, it is rejected by the
% existing controller to ensure safe operation; (2) the existing controller
% keeps the plant running near its nominal operating point by
% suppressing the perturbation signals as well.
%

%% Voltage-Mode Controlled Boost Converter
% In this example, a voltage-mode boost converter is modeled in Simulink
% using Simscape(TM) Electrical(TM) components. The parameters of these
% components are based on [1].
mdl = 'scdboostconverterPIDTuningMod';
open_system(mdl)

%%
% A boost converter circuit converts a DC voltage to another, typically
% higher, DC voltage by controlled chopping or switching of the source
% voltage. In this model, a MOSFET driven by a pulse-width modulation (PWM)
% signal is used for switching. A digital PID controller adjusts the PWM
% duty cycle to maintain the load voltage $Vout$ at its reference $Vref$.
%
% At the nominal operating point, the load voltage is 18 volts and the
% duty cycle is about 0.74. The duty cycle can vary from 0.1 to 0.85 during
% boost converter operation.
%
% The existing PID controller has gains of P = 0.02, I = 160, D = 0.00005,
% and N = 20000. These gains are stored in a Data Store Memory block and
% provided externally to the PID Controller block. Having external gain
% input ports allows you to change the values after new gains are computed
% by the Closed-Loop PID Autotuner block.

%% Connect Autotuner Block with Plant and Controller
% Insert the Closed-Loop PID Autotuner block between the PID Controller
% block and the plant, as shown in the boost converter model. The
% start/stop signal starts and stops the closed-loop experiment.  When no
% experiment is running, the Closed-Loop PID Autotuner block behaves like a
% unity gain block, where the |u| signal passes directly to |u+&Delta;u|.
%
% When using the Closed-Loop PID Autotuner block in either simulation or
% real-time applications, consider the following points.
%
% * The plant must be either asymptotically stable (all poles strictly
% stable) or integrating. The autotuner block does not work with an
% unstable plant.
%
% * The feedback loop with the existing controller must be stable.
% 
% * To estimate plant frequency responses more accurately in real time,
% minimize the occurrence of any load disturbance in the plant during the
% experiment. The autotuner block expects the plant output to be the
% response to the injected perturbation signals only, and load disturbances
% distort this output.
%
% * Because the feedback loop is closed during the experiment, the existing
% controller suppresses the injected perturbation signals as well. The
% advantage of using closed-loop experiment is that the controller keeps
% the plant running near the nominal operating point and maintains safe
% operation. The disadvantage is that it reduces the accuracy of frequency
% response estimation if your target bandwidth is far away from the current
% bandwidth.

%% Configure Autotuner Block
% After properly connecting the Closed-Loop PID Autotuner block with the
% plant model and PID Controller block, use the block parameters to specify
% tuning and experiment settings.
%
% On the *Tuning* tab, there are two main tuning settings.
%
% * *Target bandwidth*: Determines how fast you want the controller to
% respond. In this example, choose |10000| rad/sec, which is typical for a
% boost converter.
% * *Target phase margin*: Determines how robust you want the controller to
% be. In this example, choose the default value of |60| degrees.
%
% <<../boostconvertertunetab.png>>
%
% On the *Experiment* tab, there are three main experiment settings.
%
% * *Plant Type*: Specifies whether the plant is asymptotically stable or
% integrating. In this example, the boost converter plant is stable.
% * *Plant Sign*: Specifies whether the plant has a positive or negative
% sign. The plant sign is positive if a positive change in the plant input
% at the nominal operating point results in a positive change in the plant
% output when the plant reaches a new steady state. Otherwise, the plant
% sign is negative. If a plant is stable, plant sign is equivalent to the
% sign of its DC gain. If a plant is integrating, the plant sign is
% positive or negative if the plant output keeps increasing or decreasing,
% respectively. In this example, the boost converter plant has a positive
% plant sign.
% * *Signal Amplitudes*: Specifies amplitudes of the injected signal. In
% this example, choose |0.03| for all five frequencies of the perturbation
% signal to ensure the plant is properly excited within the saturation
% limit. If the excitation amplitude is too large, the boost converter
% operates in discontinuous-current mode. If the input amplitude is too
% small, the sinusoidal signals are indistinguishable from ripples in the
% power electronics circuits. Both situations produce inaccurate frequency
% response estimation results.
%
% <<../boostconverterexperimenttab.png>>
%

%% Simulate Autotuner Block in Normal Mode
% If you have a plant model built in Simulink, it is recommended to
% simulate the Closed-Loop PID Autotuner block against the plant model
% in normal mode before deploying it for real-time tuning. Simulation
% helps you identify issues with signal connections and block settings so
% that you can adjust them before generating code.

%%
% Simulation of the boost converter plant usually takes a few minutes
% because of the fast sample time of the PWM generator. |Vout| is the plant
% output and |Duty Cycle| is the plant input.
sim(mdl)

%%
% <<../boostconvertersimscope.png>>

%%
% In this example, it takes the PID controller about |0.04| seconds to
% bring the boost converter to the nominal operating point of 18 volts. The
% initial transient contains strong oscillations, which indicates that the
% existing controller must be retuned.
%
% At |0.04| seconds, the autotuning process starts. The experiment lasts
% |0.02| seconds, because the number of seconds it takes for the online
% frequency response estimation to converge is about 200 divided by the
% bandwidth.
%
% For a different nominal operating point, it can take a longer time for
% the boost converter to reach the reference voltage. You must modify the
% start/stop time signal such that the autotuning process always starts
% from the nominal operating point.
%
% When PID tuning stops at |0.06| seconds, the block calculates new gains,
% P = 0.04, I = 100, D = 0.00006, and N = 30000. The new gains are
% immediately written to the data store memory and sent to the external
% gain input ports of the PID Controller block, which overwrites the
% original gains.
%
% The model has a line disturbance (Vin from 5V to 10V) and a load current
% disturbance (Load from 6A to 3A), which occur at 0.07 and 0.08 seconds,
% respectively. You can use these disturbances to examine controller
% performance. 

%% Use PRBS Experiment Mode
% Besides the traditional sinusoidal perturbation signals, the block also
% provides an option to use the pseudo random binary sequence (PRBS) signals
% for the frequency response estimation experiment.
%
% To use PRBS as the experiment mode, adjust the signal amplitude from the 
% original |0.03| to a smaller |0.022|. The autotuning process starts at 
% |0.04| seconds and the experiment lasts for |0.021|
% seconds, as shown in the *Description* section on the *Experiment* tab.
% 
% Keep the other tuning settings unchanged and run the model. The new PID 
% gains are,  P = 0.054, I = 111.1, D = 0.00007, and N = 30000. When PID
% tuning stops at |0.061| seconds, the model updates the new gains in the 
% PID Controller block.

%%
% The new set of PID gains provide an improved closed-loop
% response with much less oscillation. Since the tuned PID gains are
% similar using the *Superposition* and *PRBS* experiment modes, the responses
% are also identical. 
%%
% <<../boostconvertercompare_expmodes.png>>


%% Use Autotuner Block in Standalone Application
% To tune a PID controller against a physical boost converter in a
% standalone real-time application, you must generate C/C++ code from
% the Closed-Loop PID Autotuner block and deploy it on your hardware.
%
% You can change the following tunable parameters at run time.
%
% * PID controller type
% * PID controller form
% * PID integrator and filter methods (discrete time only)
% * Target bandwidth
% * Target phase margin
% * Plant type
% * Plant sign
% * Amplitudes of signal
%
% The sample time of the Closed-Loop PID Autotuner block is not a tunable
% parameter. To use the autotuner block with a different sample time
% without recompiling the model, set the *Controller sample time* parameter
% of the block to |-1| and put the autotuner block inside a triggered
% subsystem. Doing so runs the autotuner at the sample time of the
% triggered subsystem.

close_system(mdl,0)

%% References
% [1] Lee, S. W. "Practical Feedback Loop Analysis for Voltage-Mode Boost
% Converter." Application Report No. SLVA633. Texas Instruments. January
% 2014. www.ti.com/lit/an/slva633/slva633.pdf